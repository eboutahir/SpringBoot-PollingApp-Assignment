import { CardButton } from "../Components";
import "./HelloComponent.css";

function HelloComponent() {
  return (
    <div class="container">
      <h1 class="title">Hello in our quiz creator</h1>
      <div className="buttonContainer">
        <CardButton title="Create a quiz" linkTo="create" />
        <CardButton title="Try to solve a quiz" linkTo="quiz" />
      </div>
    </div>
  );
}
export default HelloComponent;
