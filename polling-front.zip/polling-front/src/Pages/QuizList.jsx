function QuizList() {
    return ( <>
    <h1>Quiz list :</h1>
    </> );
}

export default QuizList;